package AnimalKingdom;

public interface Food {
    public String foodType();
    public String ediblePart();
}
